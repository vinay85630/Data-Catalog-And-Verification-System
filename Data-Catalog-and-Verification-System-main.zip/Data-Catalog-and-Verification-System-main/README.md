<h2 align="center">Valley: Data Catalog and Verification System </h2>
	
	




![](preview.png)
<hr> 

 ![](preview2.png)
 

## Instructions to run

```
npm install
npm start
```



---
<p align="center">
	Made with :heart: by <a href="http://sakshichoudhary.me">Sakshi Choudhary</a>
</p>
